# C2A Proposal: SynthRule — 合成规则学习基准测试

# SynthRule: Synthetic Rule Acquisition Benchmark for Measuring Genuine Learning in LLMs

**赛道 / Track:** Track 1 — Learning（学习）
**作者 / Author:** TestStudent
**日期 / Date:** 2026-04-05

---

## 1. 赛道选择与动机 / Track Selection & Motivation

### 为什么选择 Learning 赛道？ / Why Track 1?

当我们说一个 AI "学会了"某件事，我们到底在说什么？当前的 LLM 评估存在一个根本性混淆：**记忆（memorization）和学习（learning）被混为一谈。** 一个模型在 few-shot 提示下正确回答问题，可能是因为它在预训练数据中见过类似模式，而非因为它真正从这几个例子中获得了新能力。

When we say an AI has "learned" something, what exactly do we mean? Current LLM evaluations conflate two fundamentally different processes: retrieval of pre-trained knowledge and genuine acquisition of new capabilities from experience. A model that succeeds on few-shot prompts may be pattern-matching against its pre-training corpus, not learning from the examples provided.

这个混淆不是小问题——它直接关系到我们能否判断 AI 系统是否在向 AGI 方向进步。DeepMind 的认知框架指出，学习能力是评估缺口最大的五个认知能力之一，而核心困难正在于：**如何设计一个任务，其答案不可能存在于任何训练数据中？**

This confusion is not minor — it directly undermines our ability to measure whether AI systems are progressing toward AGI. DeepMind's cognitive framework identifies learning as one of the five abilities with the largest evaluation gap, and the core difficulty lies in designing tasks whose solutions are provably absent from all training data.

### KSTAR 连接 / KSTAR Connection

KSTAR 将学习形式化为一个闭环：K（已有知识）→ S（情境评估）→ T（任务分解）→ A（执行行动）→ R（观察结果）→ ΔR（预期与实际的偏差）→ 更新 K。**真正的学习发生在 ΔR ≠ 0 时——当结果和预期不一致，系统更新了自身的知识。** 我们的 benchmark 将直接测量这个循环：模型是否能在收到反馈后改变行为？

In KSTAR, learning is formalized as a closed loop: K → S → T → A → R → ΔR → update K. **Genuine learning occurs when ΔR ≠ 0 — when the outcome deviates from expectation, and the system updates its knowledge accordingly.** Our benchmark directly measures this loop: does the model's behavior change after receiving feedback?

---

## 2. Benchmark 设计思路 / Benchmark Design

### 2.1 核心设计：合成规则宇宙 / Core Design: Synthetic Rule Universes

SynthRule 的核心思想是**程序性生成规则系统**——每个规则系统都是全新发明的、不可能存在于任何训练数据中。

SynthRule's core idea is **procedural generation of rule systems** — each rule system is freshly invented and provably absent from any training corpus.

**规则系统的构成 / Rule System Components:**

每个"规则宇宙"由三个可组合的基本操作定义：

| 基本操作 | 示例 | 人类直觉类比 |
|----------|------|-------------|
| 变换规则（Transform） | 如果输入含 `▲`，替换为 `●●` | 类似化学反应式 |
| 条件规则（Condition） | 仅当序列长度 > 3 时执行变换 | 类似 if-then 规则 |
| 组合规则（Composition） | 先执行规则 A，再执行规则 B | 类似函数组合 |

Each "rule universe" is defined by three composable primitive operations: transforms (symbol substitutions), conditions (context-dependent activation), and compositions (sequential rule chaining).

**程序性生成保证新颖性 / Procedural Generation Guarantees Novelty:**

```python
# 示例：生成一个规则宇宙
import random

SYMBOLS = ['▲', '●', '■', '◆', '★', '○', '□', '◇']

def generate_rule_universe(complexity=2):
    rules = []
    symbols = random.sample(SYMBOLS, 4)
    for _ in range(complexity):
        rule_type = random.choice(['transform', 'condition', 'compose'])
        if rule_type == 'transform':
            rules.append(f"IF {symbols[0]} THEN replace with {symbols[1]}{symbols[2]}")
        elif rule_type == 'condition':
            rules.append(f"IF sequence length > {random.randint(2,5)}, apply rule {len(rules)}")
        else:
            rules.append(f"Apply rule {max(0,len(rules)-1)} THEN rule {len(rules)-1}")
    return rules
```

由于符号集合和规则组合是随机生成的，**每个测试实例的答案都是全新的，不可能通过预训练记忆获得。**

Since symbol sets and rule compositions are randomly generated, the answer to each test instance is genuinely novel and cannot be retrieved from pre-training memory.

### 2.2 三阶段测试协议 / Three-Phase Test Protocol

**Phase A — 零知识基线（Zero-Knowledge Baseline）**
- 给模型 20 个来自新规则宇宙的输入-输出对
- 但**不告诉模型任何规则**
- 测量：猜测准确率（应接近随机）

**Phase B — 示例学习（Example-Based Learning）**
- 提供 5 个标注的输入→输出示例（暗含规则）
- 然后测试 15 个新的输入
- 测量：学习后准确率

**Phase C — 反馈学习（Feedback Learning）**
- 模型回答后，给出正确答案作为反馈
- 在同一个规则宇宙中继续测试 10 个新输入
- 测量：反馈后准确率是否提升（KSTAR 的 ΔR→更新 K）

**关键指标 / Key Metrics:**

| 指标 | 公式 | 测量什么 |
|------|------|----------|
| 学习增益（Learning Gain） | Phase B 准确率 − Phase A 准确率 | 从示例中学到了多少 |
| 反馈增益（Feedback Gain） | Phase C 准确率 − Phase B 准确率 | 能否从纠错中学习 |
| 规则泛化度（Rule Generalization） | Phase B 在未见规则组合上的准确率 | 学的是规则还是表面模式 |
| 学习效率（Learning Efficiency） | 达到 80% 准确率所需示例数 | 学习速度 |

### 2.3 示例测试项 / Example Test Item

```
=== Rule Universe #4729 ===
Rules (hidden from model):
  R1: ▲ → ●●
  R2: IF sequence contains ■, apply R1 to all ▲; ELSE leave unchanged
  R3: After R2, reverse the sequence

--- Phase B: Learning Examples ---
Example 1: Input [■, ▲, ○]  → Output [○, ●●, ■]
Example 2: Input [▲, ○, ■]  → Output [■, ○, ●●]
Example 3: Input [▲, ○, ▲]  → Output [▲, ○, ▲]     (no ■, so no transform)
Example 4: Input [■, ▲, ▲]  → Output [▲▲, ●●, ●●]   (wait... reversed!)
Example 5: Input [○, ■, ▲]  → Output [●●, ■, ○]

--- Phase B: Test ---
Question: Input [■, ○, ▲, ▲] → Output ?
Correct:  [●●, ●●, ○, ■]
```

模型必须从 5 个示例中推断出三条隐含规则并正确应用。这不是模式匹配——而是规则归纳。

The model must infer three implicit rules from 5 examples and correctly apply them. This is rule induction, not pattern matching.

### 2.4 设计灵感 / Design Inspiration

- **ARC (Chollet, 2019)：** 借鉴了"few-shot 抽象推理"的核心思想，但 ARC 是视觉网格变换，我们使用符号序列——更容易程序化生成和自动评分
- **ARC-AGI-3 (2026)：** 借鉴了"交互式学习"的方向（我们的 Phase C 反馈机制），但简化为文本序列
- **SCAN (Lake & Baroni, 2018)：** 借鉴了"组合泛化"的测试方法，但 SCAN 的规则是固定的（存在训练数据泄漏风险），我们每次随机生成
- **KSTAR 循环：** Phase C 直接测量 "A→R→ΔR→更新 K" 这个学习闭环是否发生

---

## 3. 人类基线考量 / Human Baseline Considerations

### 人类表现分布预期 / Expected Human Performance Distribution

| 人群 | Phase A（猜测） | Phase B（示例学习） | Phase C（反馈学习） |
|------|-----------------|---------------------|---------------------|
| 儿童（8-12岁） | ~10%（随机） | 30-50% | 50-70% |
| 普通成人 | ~10%（随机） | 50-75% | 75-90% |
| 逻辑训练者 | ~10%（随机） | 70-90% | 85-95% |

### 区分度设计 / Discrimination Design

人类和 AI 在 Phase A 都应接近随机（~10%），这是基线校准。区分度来自 Phase B 和 Phase C：

- **过易风险控制：** 规则复杂度可调（1-4 条规则组合），确保不会所有人/模型都做对
- **过难风险控制：** 最简规则宇宙只有 1 条变换规则，人类准确率应 > 80%
- **难度梯度：** 40% 简单（1 条规则）、40% 中等（2 条规则）、20% 困难（3-4 条组合规则）

Difficulty is controlled by rule complexity (1–4 rules). The simplest universes have a single transform; the hardest involve conditional compositions. This creates a smooth difficulty gradient with clear discrimination power.

---

## 4. 预期创新点与可行性 / Innovation & Feasibility

### 4.1 创新点 / What's New

| 现有 Benchmark 的局限 | SynthRule 如何解决 |
|----------------------|-------------------|
| ARC：视觉格式，评分困难 | 符号序列格式，精确自动评分 |
| Few-shot prompting 测试：无法排除预训练记忆 | 程序性生成保证规则宇宙的新颖性 |
| SCAN：固定规则集，存在泄漏风险 | 每次测试随机生成新规则，不可能被记忆 |
| 静态测试：只测量一次表现 | 三阶段协议测量学习**轨迹**（baseline → examples → feedback） |
| 无 KSTAR 对接 | Phase C 直接测量 ΔR→K 更新循环 |

**最核心的创新：** 从测量"模型知道什么"转变为测量"模型能学会什么"。

The most fundamental innovation: shifting from measuring "what the model knows" to measuring "what the model can learn."

### 4.2 可行性 / Feasibility

| 资源 | 方案 | 时间 |
|------|------|------|
| 规则生成器 | Python 脚本，< 200 行代码 | 1 天 |
| 测试数据 | 程序生成 100 个规则宇宙 × 每个 45 道题 = 4500 测试项 | 1 天 |
| 评分函数 | 精确匹配（符号序列），简单可靠 | 0.5 天 |
| 模型测试 | 通过 API 调用 2-3 个前沿模型（GPT-4o, Claude, Gemini） | 2 天 |
| 文档 + 提交 | Kaggle Community Benchmarks 格式 | 1.5 天 |
| 缓冲 | 调试和迭代 | 1 天 |
| **合计** | | **7 天** |

All components are text-based, requiring no GPU training — only API inference calls. The procedural generator ensures unlimited fresh test instances, eliminating data contamination concerns entirely.

---

## 参考文献 / References

1. Chollet, F. (2019). On the Measure of Intelligence. *arXiv:1911.01547*.
2. Chollet, F. et al. (2026). ARC-AGI-3: Interactive Reasoning Benchmark. *ARC Prize*.
3. Lake, B. & Baroni, M. (2018). Generalization without Systematicity: On the Compositional Skills of Sequence-to-Sequence Recurrent Networks. *ICML*.
4. DeepMind (2026). Measuring Progress Toward AGI: A Cognitive Framework.
5. Schunk, D.H. (2020). *Learning Theories: An Educational Perspective*. 8th ed. Pearson.
6. ARC Prize 2025 Technical Report (2026). *arXiv:2601.10904*.
7. Ye, F. et al. (2024). Benchmarking LLMs via Uncertainty Quantification. *NeurIPS*.
8. Pfister, M. et al. (2025). Brute-Force Trialling on ARC-AGI. Analysis report.
