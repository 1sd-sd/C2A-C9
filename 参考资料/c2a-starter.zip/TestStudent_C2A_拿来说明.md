# 拿来说明 / Attribution

**作者 / Author:** TestStudent
**挑战 / Challenge:** C2A — Track 1 Learning
**日期 / Date:** 2026-04-05

---

## 借鉴来源 / References

| 来源 / Source | 链接 / Link | 核心思想 / Key Idea |
|---------------|-------------|---------------------|
| ARC (Chollet, 2019) | [arXiv:1911.01547](https://arxiv.org/abs/1911.01547) | 用 few-shot 抽象推理测量流体智能；核心原则：任务不能依赖预训练知识 |
| ARC-AGI-3 (2026) | [arcprize.org/arc-agi/3](https://arcprize.org/arc-agi/3) | 从静态推理进化为交互式学习评估；首次引入 agent 持续学习范式 |
| ARC Prize 2025 技术报告 | [arXiv:2601.10904](https://arxiv.org/abs/2601.10904) | Refinement loop 作为 AGI 进展核心主题；"skill vs intelligence" 的关键区分 |
| SCAN (Lake & Baroni, 2018) | [ICML 2018](https://arxiv.org/abs/1711.00350) | 组合泛化测试：用简单命令→动作序列测量系统性组合能力 |
| DeepMind AGI 框架 (2026) | [PDF](https://storage.googleapis.com/deepmind-media/DeepMind.com/Blog/measuring-progress-toward-agi/measuring-progress-toward-agi-a-cognitive-framework.pdf) | 10 个认知能力分类法 + 三阶段评估协议 + Learning 赛道评估缺口分析 |
| KSTAR 框架 | 课程资料 | K→S→T→A→R 认知循环；ΔR 作为学习信号 |
| LLM-Uncertainty-Bench (Ye et al., 2024) | [arXiv:2401.12794](https://arxiv.org/abs/2401.12794) | 多任务跨域 LLM 评估框架；启发了多复杂度梯度设计 |

---

## 拿来的部分 / Adopted

### 从 ARC 拿了什么
- **拿了：** "few-shot 抽象推理 + 任务不能依赖预训练知识"的核心设计哲学
- **为什么好用：** ARC 是唯一一个在 LLM 时代持续有效的 AGI benchmark，说明其"去记忆化"的设计原则是对的

### 从 SCAN 拿了什么
- **拿了：** "组合规则系统"的任务形式——将学习能力拆解为"从示例中归纳规则 + 将规则组合应用于新输入"
- **为什么好用：** 符号序列变换比视觉网格更容易程序化生成和自动评分

### 从 ARC-AGI-3 拿了什么
- **拿了：** "交互式学习"的评估范式——不止测试一次性表现，而是测试模型能否从反馈中改进
- **为什么好用：** 直接对接 KSTAR 的 ΔR→K 更新循环，使 benchmark 测量真正的学习而非一次性推理

### 从 DeepMind 框架拿了什么
- **拿了：** 三阶段评估协议的理念（baseline → task → comparison with human），改造为我们的 Phase A/B/C
- **为什么好用：** 有人类基线做参照，才能有意义地解读 AI 的得分

---

## 去掉的部分 / Removed

| 来源 | 他们做了什么 | 我不要 | 原因 |
|------|------------|--------|------|
| ARC | 视觉网格变换格式 | 去掉视觉格式，改用符号序列 | 视觉格式难以程序化生成大量新题，且评分需要精确网格匹配，容错性低 |
| SCAN | 固定的命令→动作映射规则集 | 去掉固定规则集 | 固定规则集存在训练数据泄漏风险；已有研究表明 LLM 可能已"见过" SCAN |
| ARC-AGI-3 | 完整的交互式 agent 环境 | 去掉复杂的环境交互 | 过于复杂，一周内无法实现；我们只保留"反馈后改进"这个核心机制 |
| LLM-Uncertainty-Bench | 置信度量化和不确定性分析 | 去掉元认知维度 | 我们专注 Learning 赛道，不混入 Metacognition 评估 |

---

## 我的改进 / My Improvements

### 改进 1：程序性生成规则宇宙（核心创新）

- **现有方法的问题：** ARC 手工设计任务（扩展性差），SCAN 使用固定规则（泄漏风险）
- **我的改进：** 用 Python 程序随机生成"规则宇宙"——每次测试产生全新的符号集 + 规则组合
- **效果：**
  - 无限量的新题目，彻底消除训练数据泄漏问题
  - 每个规则宇宙的难度可精确控制（1-4 条规则）
  - 自动评分：符号序列精确匹配，无需人工判断

### 改进 2：三阶段学习轨迹测量

- **现有方法的问题：** 大多数 benchmark 只测量"一次性表现"（snapshot），无法区分学习和记忆
- **我的改进：** Phase A（基线）→ Phase B（示例学习）→ Phase C（反馈学习），测量完整的学习曲线
- **效果：**
  - Learning Gain = Phase B − Phase A：量化"从示例中学到多少"
  - Feedback Gain = Phase C − Phase B：量化"能否从纠错中进步"（KSTAR ΔR→K 更新）
  - 学习轨迹比单一得分提供 3 倍以上的信息量

### 改进 3：KSTAR 对齐的评估指标

- **现有方法的问题：** 评估指标缺乏认知科学理论支撑
- **我的改进：** 将 KSTAR 循环直接映射为评估指标
  - Phase B 测量 K（从示例中建立知识）→ A（执行）→ R（结果）
  - Phase C 测量 ΔR（偏差）→ K 更新 → A'（改进后的执行）→ R'（改进后的结果）
- **效果：** 每个指标都有明确的认知科学解释，而非纯统计数字
